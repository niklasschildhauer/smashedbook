export enum Environment {
	DEV = 'dev',
	STAGE = 'stage',
	PROD = 'prod',
}